package examenClases_LuisRodriguez.vehiculos;

import examenClases_LuisRodriguez.personas.Pasajero;

public class Motocicleta extends Vehiculo {

    private int cilindrada;
    private boolean carnet;


    public Motocicleta(String matricula, int cilindrada, boolean carnet) {
        super(matricula);
        this.cilindrada = cilindrada;
        this.carnet = carnet;

        
    }

    

    @Override
    public void setPropietario(Pasajero pasajero) {
        
        this.propietario = pasajero;
    }
    
    public Pasajero getPropietario() {
        return propietario;
    }

    @Override
    public String toString() {
        
        return super.toString()+" - Cilindrada: "+this.cilindrada+" Con Carnet"+this.carnet;
    }
    
}
