package examenClases_LuisRodriguez.vehiculos;

import examenClases_LuisRodriguez.personas.Pasajero;

public abstract class Vehiculo {
    
    protected String matricula;
    protected Pasajero propietario;

    public Vehiculo(String matricula){}

    public abstract void setPropietario(Pasajero pasajero);

    @Override
    public String toString() {
        
        return "Matricula ="+this.matricula+" - "+propietario.toString();

    }

    public Pasajero getPropietario() {
        return propietario;
    }

}
