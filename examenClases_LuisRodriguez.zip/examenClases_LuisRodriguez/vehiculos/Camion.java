package examenClases_LuisRodriguez.vehiculos;

import examenClases_LuisRodriguez.personas.Pasajero;

public class Camion extends Vehiculo {

    private double pesoMax;
    private boolean mercanciaPeli;



    public Camion(String matricula,double pesoMax) {
        super(matricula);
        this.pesoMax = pesoMax;
        
    }

    

    @Override
    public void setPropietario(Pasajero pasajero) {
        this.propietario = pasajero;
    }

    public Pasajero getPropietario() {
        return propietario;
    }

    @Override
    public String toString() {
        return super.toString()+" - Capacidad de carga: "+this.pesoMax+" Carga peligrosa"+this.mercanciaPeli;
    }   
    
}
