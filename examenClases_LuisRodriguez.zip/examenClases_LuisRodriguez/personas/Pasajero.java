package examenClases_LuisRodriguez.personas;

public class Pasajero {

    private String nombre;
    private String apellidos;
    private String nacionalidad;
    private boolean camarote;
    private static int aux = 0;
    private int codigoID;
    private boolean embarcado;


    public Pasajero(String nombre, String apellidos, String nacionalidad, boolean camarote)
    {
        aux++;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.nacionalidad = nacionalidad;
        this.camarote = camarote;
        this.codigoID = aux;

        
        
    }


    public boolean isEmbarcado() {
        return embarcado;
    }


    public void setEmbarcado(boolean embarcado) {
        this.embarcado = embarcado;
    }


    public String getNombre() {
        return nombre;
    }


    public String getApellidos() {
        return apellidos;
    }


    public String getNacionalidad() {
        return nacionalidad;
    }

    
    @Override
    public String toString() {
        
        return this.nombre +" - "+this.apellidos+" - "+this.nacionalidad+" - "+camarote+" (Codigo ="+this.codigoID+")";
    }



}
