

import clases.Ferreteria;

public class App {
    public static void main(String[] args) throws Exception {

        Ferreteria ferreteriaPako = new Ferreteria();

        ferreteriaPako.facturacionTotal();
        ferreteriaPako.FacturacionClientes();
        

    }   
}
