package clases;

public class ExcepcionProductoSinStock extends Exception  
{
    
    public ExcepcionProductoSinStock(String msg)
    {
        super(msg);
    }

}
