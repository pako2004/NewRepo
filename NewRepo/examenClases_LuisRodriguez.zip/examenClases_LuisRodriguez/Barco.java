package examenClases_LuisRodriguez;

import java.util.Arrays;

import examenClases_LuisRodriguez.personas.Pasajero;
import examenClases_LuisRodriguez.vehiculos.Vehiculo;

public class Barco {
    
    private int capacidadVehi;
    private int capacidadPerson;
    private double totalKg;
    private String nombre;
    private int fecha;
    private Pasajero[] pasajeros;
    private Vehiculo[] vehiculos;
    
    
    public Barco(String nombre, int fecha, double totalKg, int capacidadVehi, int capacidadPerson )
    {
        this.nombre = nombre;
        this. fecha = fecha;
        this.totalKg = totalKg;
        this.capacidadVehi = capacidadVehi;
        this.capacidadPerson = capacidadPerson;

    }
    /**
     * Retorna si el pasajero ya se encuentra en el barco
     * @param nombre
     * @param apellidos
     * @param nacionalidad
     * @return
     */
    boolean repetido(String nombre, String apellidos, String nacionalidad) 
    {
        boolean repedito = false;

        for (int i = 0; i < pasajeros.length; i++) {
            
            if (nombre.equals((String)pasajeros[i].getNombre()) && apellidos.equals((String)pasajeros[i].getApellidos()) 
            && nacionalidad.equals((String)pasajeros[i].getNombre()))
            {
                repedito = true;
            }
        }

        return repedito;
    }

    public void embarcarPasajero(Pasajero pasajero)
    {   
        if(repetido(pasajero.getNombre(),pasajero.getApellidos() , pasajero.getNacionalidad()))
        {
        this.pasajeros = addPasajero(pasajero);
        pasajero.setEmbarcado(true);
        }else{
            System.out.println("Esta pasajero ya ha embarcado con aterioridad");
        }
    }

    public Pasajero[] addPasajero (Pasajero pasajero)
    {   
        Pasajero[] newArrays = Arrays.copyOf(this.pasajeros, this.pasajeros.length+1);
        for (int i = 0; i < this.pasajeros.length; i++) {
                newArrays[i] = this.pasajeros[i];
        }
        newArrays[newArrays.length-1] = pasajero;
        return newArrays;
    }

    public void embarcarVehiculo(Vehiculo vehiculo)
    {
        if (vehiculo.getPropietario().isEmbarcado())
        {
        this.vehiculos = addVehiculo(vehiculo);
        }else{
            System.out.println("El propietario de este vehiculo ("+vehiculo.getPropietario()+"No ha embarcado");
        }
    }


    public Vehiculo[] addVehiculo(Vehiculo vehiculo)
    {

        Vehiculo[] newArrays = Arrays.copyOf(this.vehiculos, this.vehiculos.length+1);
        for (int i = 0; i < this.pasajeros.length; i++) {
                newArrays[i] = this.vehiculos[i];
        }
        newArrays[newArrays.length-1] = vehiculo;
        return newArrays;

        
    }

    public void desembarcarVehiculo()
    {
        this.vehiculos = quitarVehiculo();
    }

    public Vehiculo[] quitarVehiculo()
    {   
        Pasajero propie = this.vehiculos[this.vehiculos.length-1].getPropietario();
        Vehiculo[] newArrays = Arrays.copyOf(this.vehiculos, this.vehiculos.length-1);
        for (int i = 0; i < this.pasajeros.length; i++) {
                newArrays[i] = this.vehiculos[i];
        }
        return newArrays;

        
    }


    public void informacionBarco()
    {
        System.out.println("XXXXXXX BARCO:" +this.nombre+"XXXXXXX");

        System.out.println(this.nombre+" - Per. Max: "+this.capacidadPerson+" - Vehi. Max: "+this.capacidadVehi
        +" - Kgs Maximo:"+this.totalKg+" - Botadura: "+this.fecha); //Caracteristicas del barco
        
        System.out.println("Pasajeros: ("+this.pasajeros.length+")");
        for (int i = 0; i < pasajeros.length; i++) {
            pasajeros[i].toString();
        }
        System.out.println("-----------------");
        System.out.println("Vehiculos ("+this.vehiculos.length+")");
        for (int i = 0; i < vehiculos.length; i++) {
            vehiculos[i].toString();
        }
    }

    public void informacionPasajeros()
    {
        System.out.println("XXXXXXX BARCO:" +this.nombre+"XXXXXXX");
        System.out.println("Pasajeros: ("+this.pasajeros.length+")");
        for (int i = 0; i < pasajeros.length; i++) {
            pasajeros[i].toString();
        }
    }

    public void informacionVehiculos()
    {
        System.out.println("XXXXXXX BARCO:" +this.nombre+"XXXXXXX");
        System.out.println("Vehiculos ("+this.vehiculos.length+")");
        for (int i = 0; i < vehiculos.length; i++) {
            vehiculos[i].toString();
        }
    }






   


}
