package examenClases_LuisRodriguez.vehiculos;

import examenClases_LuisRodriguez.personas.Pasajero;

public class Coche extends Vehiculo {

    private int numPlazas;
    private boolean tipoUso;


    public Coche(String matricula, int numPlazas, boolean tipoUso) {
        super(matricula);
        this.numPlazas = numPlazas;
        this.tipoUso = tipoUso;
        //TODO Auto-generated constructor stub
    }
    @Override
    public void setPropietario(Pasajero pasajero){
        this.propietario = pasajero;
       
    }

    public Pasajero getPropietario() {
        return propietario;
    }
    
    @Override
    public String toString() {
        
        return super.toString()+"- Num Puestas"+this.numPlazas+" -Es particular: "+this.tipoUso;
    }
    
}
