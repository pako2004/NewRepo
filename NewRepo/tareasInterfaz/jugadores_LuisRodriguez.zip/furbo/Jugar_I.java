package tareasInterfaz.furbo;

public interface Jugar_I {
    

    public void HacerGol(Jugador jugador);
    public void cometerFalta(Jugador jugador);




}
