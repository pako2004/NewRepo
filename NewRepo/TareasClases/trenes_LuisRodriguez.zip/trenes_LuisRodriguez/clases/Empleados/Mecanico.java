package trenes_LuisRodriguez.clases.Empleados;

public class Mecanico {
    

    //Atributos 

    private String nombre;
    private String especialidad;
    private int tlf;

    //Constructor

    public Mecanico(String nombre, int tlf, String especialidad){

        this.nombre = nombre;
        this.tlf = tlf;
        this.especialidad = especialidad;

    }

}
